
function LogEvent(){
    var login = document.getElementById("login");
    var signup = document.getElementById("signup");
    login.style.width="60%";
    login.style.fontWeight="bold";
    login.style.background = "#565ABB";

    signup.style.width = "40%";
    signup.style.fontWeight="normal";
    signup.style.background = "black"

}
function SignEvent(){
    var login = document.getElementById("login");
    var signup = document.getElementById("signup");
    signup.style.width="60%";
    signup.style.fontWeight="bold";
    signup.style.background = "#565ABB";

    login.style.width = "40%";
    login.style.fontWeight="normal";
    login.style.background = "black"

}